
  # Luxury Saree Brand Website

  This is a code bundle for Luxury Saree Brand Website. The original project is available at https://www.figma.com/design/zDyNflMWkZECsaQ3Ogh0HL/Luxury-Saree-Brand-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  