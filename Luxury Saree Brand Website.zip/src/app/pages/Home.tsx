import { Link } from "react-router";
import { motion } from "motion/react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import { products } from "@/app/data/products";

export default function Home() {
  const featuredProducts = products.slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-neutral-beige)] to-[var(--color-primary-bg)]" />
        
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="font-heading text-5xl md:text-7xl mb-6 text-[var(--color-primary-text)]"
          >
            Woven by Hand.
            <br />
            <span className="text-[var(--color-accent-maroon)]">Preserved by Tradition.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl mb-10 text-[var(--color-primary-text)]/80 max-w-2xl mx-auto"
          >
            Each saree tells a story of artisan craftsmanship, cultural heritage, and timeless elegance. 
            Discover the art of slow fashion.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Link 
              to="/collection" 
              className="inline-block px-12 py-4 bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)] hover:bg-[var(--color-accent-gold)] hover:text-[var(--color-primary-text)] transition-all duration-300"
            >
              Explore Collection
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Brand Philosophy */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="grid md:grid-cols-2 gap-16 items-center"
          >
            <div>
              <h2 className="font-heading text-4xl md:text-5xl mb-6 text-[var(--color-accent-maroon)]">
                Heritage Meets Craftsmanship
              </h2>
              <p className="text-lg mb-6 text-[var(--color-primary-text)]/80 leading-relaxed">
                In an era of fast fashion, we stand for something timeless. Each of our sarees is a masterpiece, 
                handwoven by skilled artisans who have inherited this sacred craft through generations.
              </p>
              <p className="text-lg mb-6 text-[var(--color-primary-text)]/80 leading-relaxed">
                We believe in slow fashion — garments created with patience, precision, and profound respect for tradition. 
                Every thread tells a story, every pattern preserves a legacy.
              </p>
              <Link 
                to="/about" 
                className="inline-block text-[var(--color-accent-gold)] hover:text-[var(--color-accent-maroon)] transition-colors border-b-2 border-[var(--color-accent-gold)] hover:border-[var(--color-accent-maroon)] pb-1"
              >
                Learn Our Story →
              </Link>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1739185127141-bb4aa70ad22a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbG9vbSUyMHdlYXZpbmclMjBhcnRpc2FufGVufDF8fHx8MTc2OTA3MjkzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Artisan weaving"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl md:text-5xl mb-4 text-[var(--color-accent-maroon)]">
              Featured Collection
            </h2>
            <p className="text-lg text-[var(--color-primary-text)]/80 max-w-2xl mx-auto">
              Handpicked masterpieces that showcase the pinnacle of artisan craftsmanship
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {featuredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                <Link to={`/collection/${product.id}`} className="group block">
                  <div className="relative h-96 mb-4 overflow-hidden rounded-lg shadow-lg">
                    <ImageWithFallback 
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4 bg-[var(--color-accent-gold)] text-[var(--color-primary-text)] px-3 py-1 text-xs">
                      {product.clothType}
                    </div>
                  </div>
                  <h3 className="font-heading text-2xl mb-2 text-[var(--color-primary-text)] group-hover:text-[var(--color-accent-maroon)] transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-[var(--color-primary-text)]/70 mb-2">{product.description}</p>
                  <p className="text-sm text-[var(--color-primary-text)]/60">
                    Handwoven in {product.weavingTime}
                  </p>
                  <p className="text-[var(--color-accent-gold)] mt-2">{product.price}</p>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link 
              to="/collection" 
              className="inline-block px-10 py-3 border-2 border-[var(--color-accent-maroon)] text-[var(--color-accent-maroon)] hover:bg-[var(--color-accent-maroon)] hover:text-[var(--color-primary-bg)] transition-all duration-300"
            >
              View Full Collection
            </Link>
          </div>
        </div>
      </section>

      {/* Craftsmanship Process */}
      <section className="py-20 px-4 bg-[var(--color-neutral-beige)]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl md:text-5xl mb-4 text-[var(--color-accent-maroon)]">
              The Art of Creation
            </h2>
            <p className="text-lg text-[var(--color-primary-text)]/80 max-w-2xl mx-auto">
              From thread to treasure, witness the journey of each handwoven saree
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Thread Selection", description: "Choosing the finest cotton or silk threads" },
              { step: "02", title: "Design Planning", description: "Mapping intricate patterns and motifs" },
              { step: "03", title: "Hand Weaving", description: "Skilled artisans weave each thread with precision" },
              { step: "04", title: "Quality Check", description: "Ensuring perfection in every detail" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-5xl font-heading text-[var(--color-accent-gold)] mb-4">
                  {item.step}
                </div>
                <h3 className="font-heading text-xl mb-3 text-[var(--color-primary-text)]">
                  {item.title}
                </h3>
                <p className="text-[var(--color-primary-text)]/70">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link 
              to="/craftsmanship" 
              className="inline-block text-[var(--color-accent-maroon)] hover:text-[var(--color-accent-gold)] transition-colors border-b-2 border-[var(--color-accent-maroon)] hover:border-[var(--color-accent-gold)] pb-1"
            >
              Discover the Process →
            </Link>
          </div>
        </div>
      </section>

      {/* Artisan Spotlight */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="grid md:grid-cols-2 gap-16 items-center"
          >
            <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl order-2 md:order-1">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1739185127141-bb4aa70ad22a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbG9vbSUyMHdlYXZpbmclMjBhcnRpc2FufGVufDF8fHx8MTc2OTA3MjkzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Master artisan"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="order-1 md:order-2">
              <div className="inline-block px-4 py-1 bg-[var(--color-accent-gold)]/20 text-[var(--color-accent-maroon)] text-sm mb-4">
                ARTISAN SPOTLIGHT
              </div>
              <h2 className="font-heading text-4xl mb-6 text-[var(--color-primary-text)]">
                "Every thread carries the wisdom of generations"
              </h2>
              <p className="text-lg mb-4 text-[var(--color-primary-text)]/80 leading-relaxed">
                Meet the master weavers behind our sarees. These skilled artisans have devoted their lives 
                to preserving traditional techniques passed down through families for centuries.
              </p>
              <p className="text-lg mb-6 text-[var(--color-primary-text)]/80 leading-relaxed">
                Their hands create magic, transforming simple threads into timeless works of art. 
                Each saree is not just a garment, but a piece of living heritage.
              </p>
              <p className="text-sm text-[var(--color-accent-gold)]">
                — Master Weaver, 40+ years of experience
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 bg-[var(--color-neutral-beige)]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl md:text-5xl mb-4 text-[var(--color-accent-maroon)]">
              What Our Customers Say
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                quote: "The craftsmanship is unparalleled. This saree is not just beautiful, it's a work of art.",
                author: "Priya S.",
                location: "Mumbai"
              },
              {
                quote: "Wearing this saree makes me feel connected to my heritage. The quality is exceptional.",
                author: "Anjali K.",
                location: "Kolkata"
              },
              {
                quote: "Worth every penny. The attention to detail and the story behind each piece is remarkable.",
                author: "Meera R.",
                location: "Chennai"
              }
            ].map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-8 rounded-lg shadow-md"
              >
                <p className="text-lg mb-6 text-[var(--color-primary-text)]/80 italic leading-relaxed">
                  "{testimonial.quote}"
                </p>
                <div className="border-t border-[var(--color-neutral-beige)] pt-4">
                  <p className="font-heading text-[var(--color-primary-text)]">{testimonial.author}</p>
                  <p className="text-sm text-[var(--color-primary-text)]/60">{testimonial.location}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading text-4xl md:text-5xl mb-6">
            Begin Your Journey
          </h2>
          <p className="text-lg mb-10 opacity-90">
            Discover sarees that tell stories, preserve traditions, and celebrate timeless elegance
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              to="/collection" 
              className="inline-block px-10 py-4 bg-[var(--color-accent-gold)] text-[var(--color-primary-text)] hover:bg-[var(--color-primary-bg)] transition-all duration-300"
            >
              Explore Collection
            </Link>
            <Link 
              to="/contact" 
              className="inline-block px-10 py-4 border-2 border-[var(--color-primary-bg)] text-[var(--color-primary-bg)] hover:bg-[var(--color-primary-bg)] hover:text-[var(--color-accent-maroon)] transition-all duration-300"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
