import { motion } from "motion/react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export default function About() {
  return (
    <div className="min-h-screen bg-[var(--color-primary-bg)]">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-[var(--color-neutral-beige)]">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-heading text-5xl md:text-6xl mb-6 text-[var(--color-accent-maroon)]"
          >
            About Heritage Sarees
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-[var(--color-primary-text)]/80"
          >
            Preserving tradition through handwoven excellence
          </motion.p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-heading text-4xl mb-6 text-[var(--color-accent-maroon)]">
                Our Story
              </h2>
              <p className="text-lg mb-4 text-[var(--color-primary-text)]/80 leading-relaxed">
                Heritage Sarees was born from a deep reverence for tradition and a passion for preserving 
                artisanal craftsmanship. For generations, skilled weavers have created masterpieces that 
                tell stories of culture, heritage, and timeless beauty.
              </p>
              <p className="text-lg mb-4 text-[var(--color-primary-text)]/80 leading-relaxed">
                In an era dominated by mass production, we stand as custodians of slow fashion. Each saree 
                in our collection represents countless hours of patient labor, intricate skill, and profound 
                dedication to an art form that has been passed down through generations.
              </p>
              <p className="text-lg text-[var(--color-primary-text)]/80 leading-relaxed">
                We work directly with artisan communities, ensuring fair compensation and supporting the 
                preservation of traditional weaving techniques that might otherwise be lost to time.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative h-96 rounded-lg overflow-hidden shadow-2xl"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1739185127141-bb4aa70ad22a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbG9vbSUyMHdlYXZpbmclMjBhcnRpc2FufGVufDF8fHx8MTc2OTA3MjkzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Artisan weaving"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>

          {/* Our Values */}
          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {[
              {
                title: "Authenticity",
                description: "Every saree is genuinely handwoven by skilled artisans using traditional techniques."
              },
              {
                title: "Quality",
                description: "We never compromise on the quality of materials or craftsmanship in our sarees."
              },
              {
                title: "Sustainability",
                description: "Our slow fashion approach supports artisan communities and preserves cultural heritage."
              }
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-8 rounded-lg shadow-md"
              >
                <h3 className="font-heading text-2xl mb-4 text-[var(--color-accent-maroon)]">
                  {value.title}
                </h3>
                <p className="text-[var(--color-primary-text)]/80">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Our Mission */}
          <div className="bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)] p-12 rounded-lg">
            <h2 className="font-heading text-4xl mb-6 text-center">Our Mission</h2>
            <p className="text-lg text-center max-w-3xl mx-auto leading-relaxed">
              To preserve and celebrate the art of handwoven sarees while supporting artisan communities, 
              ensuring that this precious cultural heritage continues to thrive for generations to come.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
