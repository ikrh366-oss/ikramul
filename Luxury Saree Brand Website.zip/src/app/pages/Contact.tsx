import { motion } from "motion/react";
import { Mail, Phone, MessageCircle, MapPin } from "lucide-react";

export default function Contact() {
  const handleWhatsApp = () => {
    window.open('https://wa.me/910000000000', '_blank');
  };

  return (
    <div className="min-h-screen bg-[var(--color-primary-bg)]">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-[var(--color-neutral-beige)]">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-heading text-5xl md:text-6xl mb-6 text-[var(--color-accent-maroon)]"
          >
            Get in Touch
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-[var(--color-primary-text)]/80"
          >
            We'd love to hear from you. Reach out for inquiries, custom orders, or just to say hello.
          </motion.p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            {/* Contact Details */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-heading text-3xl mb-8 text-[var(--color-accent-maroon)]">
                Contact Information
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[var(--color-accent-gold)]/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-[var(--color-accent-maroon)]" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg mb-1">Email</h3>
                    <a 
                      href="mailto:contact@heritagesarees.com" 
                      className="text-[var(--color-primary-text)]/70 hover:text-[var(--color-accent-gold)] transition-colors"
                    >
                      contact@heritagesarees.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[var(--color-accent-gold)]/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-[var(--color-accent-maroon)]" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg mb-1">Phone</h3>
                    <a 
                      href="tel:+910000000000" 
                      className="text-[var(--color-primary-text)]/70 hover:text-[var(--color-accent-gold)] transition-colors"
                    >
                      +91 00000 00000
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[var(--color-accent-gold)]/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="w-5 h-5 text-[var(--color-accent-maroon)]" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg mb-1">WhatsApp</h3>
                    <button 
                      onClick={handleWhatsApp}
                      className="text-[var(--color-primary-text)]/70 hover:text-[var(--color-accent-gold)] transition-colors text-left"
                    >
                      +91 00000 00000<br />
                      <span className="text-sm">Click to chat with us</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[var(--color-accent-gold)]/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-[var(--color-accent-maroon)]" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg mb-1">Location</h3>
                    <p className="text-[var(--color-primary-text)]/70">
                      Heritage Sarees Boutique<br />
                      [Your Address]<br />
                      [City, State - Pincode]
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-[var(--color-neutral-beige)] rounded-lg">
                <h3 className="font-heading text-lg mb-3">Business Hours</h3>
                <div className="space-y-1 text-[var(--color-primary-text)]/70">
                  <p>Monday - Saturday: 10:00 AM - 7:00 PM</p>
                  <p>Sunday: By Appointment Only</p>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-lg"
            >
              <h2 className="font-heading text-3xl mb-6 text-[var(--color-accent-maroon)]">
                Send us a Message
              </h2>
              
              <form className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm mb-2 text-[var(--color-primary-text)]">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    required
                    className="w-full px-4 py-3 border border-[var(--color-neutral-beige)] rounded-lg focus:outline-none focus:border-[var(--color-accent-gold)] transition-colors"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm mb-2 text-[var(--color-primary-text)]">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    className="w-full px-4 py-3 border border-[var(--color-neutral-beige)] rounded-lg focus:outline-none focus:border-[var(--color-accent-gold)] transition-colors"
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm mb-2 text-[var(--color-primary-text)]">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full px-4 py-3 border border-[var(--color-neutral-beige)] rounded-lg focus:outline-none focus:border-[var(--color-accent-gold)] transition-colors"
                    placeholder="+91 00000 00000"
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm mb-2 text-[var(--color-primary-text)]">
                    Subject *
                  </label>
                  <select
                    id="subject"
                    required
                    className="w-full px-4 py-3 border border-[var(--color-neutral-beige)] rounded-lg focus:outline-none focus:border-[var(--color-accent-gold)] transition-colors"
                  >
                    <option value="">Select a subject</option>
                    <option value="product-inquiry">Product Inquiry</option>
                    <option value="custom-order">Custom Order</option>
                    <option value="bulk-order">Bulk Order</option>
                    <option value="general">General Inquiry</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm mb-2 text-[var(--color-primary-text)]">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={5}
                    className="w-full px-4 py-3 border border-[var(--color-neutral-beige)] rounded-lg focus:outline-none focus:border-[var(--color-accent-gold)] transition-colors resize-none"
                    placeholder="Tell us about your inquiry..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full px-8 py-4 bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)] hover:bg-[var(--color-accent-gold)] hover:text-[var(--color-primary-text)] transition-all duration-300"
                >
                  Send Message
                </button>

                <p className="text-xs text-[var(--color-primary-text)]/60 text-center">
                  We typically respond within 24 hours
                </p>
              </form>
            </motion.div>
          </div>

          {/* WhatsApp CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)] p-10 rounded-lg text-center"
          >
            <h2 className="font-heading text-3xl mb-4">Prefer WhatsApp?</h2>
            <p className="text-lg mb-6 opacity-90">
              Get instant responses to your queries. Chat with us directly on WhatsApp.
            </p>
            <button
              onClick={handleWhatsApp}
              className="inline-flex items-center gap-2 px-8 py-4 bg-[var(--color-accent-gold)] text-[var(--color-primary-text)] hover:bg-[var(--color-primary-bg)] transition-all duration-300"
            >
              <MessageCircle className="w-5 h-5" />
              Chat on WhatsApp
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
