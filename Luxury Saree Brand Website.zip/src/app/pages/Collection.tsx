import { useState, useMemo } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import { products, Product } from "@/app/data/products";
import { Slider } from "@/app/components/ui/slider";
import { X } from "lucide-react";

const clothTypes = ["All", "Jamdani", "Tangail", "Silk", "Cotton", "Muslin-inspired"];
const occasions = ["All", "Bridal", "Festive", "Everyday Elegance"];
const colors = ["All", "Crimson", "Gold", "Indigo", "Ivory", "Emerald", "Rust", "Beige", "Pearl White", "Silver", "Magenta"];

export default function Collection() {
  const [selectedClothType, setSelectedClothType] = useState<string>("All");
  const [selectedOccasion, setSelectedOccasion] = useState<string>("All");
  const [selectedColor, setSelectedColor] = useState<string>("All");
  const [priceRange, setPriceRange] = useState<number[]>([0, 50000]);
  const [showFilters, setShowFilters] = useState(true);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Cloth type filter
      if (selectedClothType !== "All" && product.clothType !== selectedClothType) {
        return false;
      }

      // Occasion filter
      if (selectedOccasion !== "All" && product.occasion !== selectedOccasion) {
        return false;
      }

      // Color filter
      if (selectedColor !== "All" && !product.colors.includes(selectedColor)) {
        return false;
      }

      // Price filter
      const productPrice = product.price === "Contact for Price" ? 50000 : parseInt(product.price.replace(/[₹,]/g, ""));
      if (productPrice < priceRange[0] || productPrice > priceRange[1]) {
        return false;
      }

      return true;
    });
  }, [selectedClothType, selectedOccasion, selectedColor, priceRange]);

  const clearFilters = () => {
    setSelectedClothType("All");
    setSelectedOccasion("All");
    setSelectedColor("All");
    setPriceRange([0, 50000]);
  };

  const activeFiltersCount = [
    selectedClothType !== "All",
    selectedOccasion !== "All",
    selectedColor !== "All",
    priceRange[0] !== 0 || priceRange[1] !== 50000
  ].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-[var(--color-primary-bg)]">
      {/* Hero Section */}
      <section className="py-16 px-4 bg-[var(--color-neutral-beige)]">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="font-heading text-5xl md:text-6xl mb-4 text-[var(--color-accent-maroon)]">
            Our Collection
          </h1>
          <p className="text-lg text-[var(--color-primary-text)]/80 max-w-2xl mx-auto">
            Explore our curated selection of handwoven sarees, each telling its own story
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Filters Sidebar */}
          <aside className={`lg:col-span-1 mb-8 lg:mb-0 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            <div className="bg-white p-6 rounded-lg shadow-md sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-heading text-2xl text-[var(--color-primary-text)]">Filters</h2>
                {activeFiltersCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="text-sm text-[var(--color-accent-gold)] hover:text-[var(--color-accent-maroon)] flex items-center gap-1"
                  >
                    <X className="w-4 h-4" />
                    Clear
                  </button>
                )}
              </div>

              {/* Cloth Type Filter */}
              <div className="mb-8">
                <h3 className="font-heading text-lg mb-4 text-[var(--color-primary-text)]">Cloth Type</h3>
                <div className="space-y-2">
                  {clothTypes.map((type) => (
                    <label key={type} className="flex items-center cursor-pointer group">
                      <input
                        type="radio"
                        name="clothType"
                        checked={selectedClothType === type}
                        onChange={() => setSelectedClothType(type)}
                        className="w-4 h-4 text-[var(--color-accent-gold)] focus:ring-[var(--color-accent-gold)]"
                      />
                      <span className="ml-3 text-[var(--color-primary-text)]/80 group-hover:text-[var(--color-accent-maroon)]">
                        {type}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Price Range Filter */}
              <div className="mb-8">
                <h3 className="font-heading text-lg mb-4 text-[var(--color-primary-text)]">Price Range</h3>
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  min={0}
                  max={50000}
                  step={1000}
                  className="mb-4"
                />
                <div className="flex justify-between text-sm text-[var(--color-primary-text)]/70">
                  <span>₹{priceRange[0].toLocaleString()}</span>
                  <span>₹{priceRange[1].toLocaleString()}</span>
                </div>
              </div>

              {/* Color Filter */}
              <div className="mb-8">
                <h3 className="font-heading text-lg mb-4 text-[var(--color-primary-text)]">Color</h3>
                <div className="flex flex-wrap gap-2">
                  {colors.map((color) => {
                    const colorMap: Record<string, string> = {
                      "Crimson": "bg-red-700",
                      "Gold": "bg-yellow-600",
                      "Indigo": "bg-indigo-700",
                      "Ivory": "bg-stone-100",
                      "Emerald": "bg-emerald-600",
                      "Rust": "bg-orange-800",
                      "Beige": "bg-amber-100",
                      "Pearl White": "bg-white",
                      "Silver": "bg-gray-300",
                      "Magenta": "bg-pink-600"
                    };

                    if (color === "All") {
                      return (
                        <button
                          key={color}
                          onClick={() => setSelectedColor(color)}
                          className={`px-3 py-1 text-sm rounded-full transition-all ${
                            selectedColor === color
                              ? "bg-[var(--color-accent-maroon)] text-white"
                              : "bg-[var(--color-neutral-beige)] text-[var(--color-primary-text)] hover:bg-[var(--color-accent-gold)]/20"
                          }`}
                        >
                          {color}
                        </button>
                      );
                    }

                    return (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`w-8 h-8 rounded-full border-2 transition-all ${
                          selectedColor === color
                            ? "border-[var(--color-accent-maroon)] ring-2 ring-[var(--color-accent-maroon)] ring-offset-2"
                            : "border-gray-300 hover:border-[var(--color-accent-gold)]"
                        } ${colorMap[color] || "bg-gray-200"}`}
                        title={color}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Occasion Filter */}
              <div className="mb-6">
                <h3 className="font-heading text-lg mb-4 text-[var(--color-primary-text)]">Occasion</h3>
                <div className="space-y-2">
                  {occasions.map((occasion) => (
                    <label key={occasion} className="flex items-center cursor-pointer group">
                      <input
                        type="radio"
                        name="occasion"
                        checked={selectedOccasion === occasion}
                        onChange={() => setSelectedOccasion(occasion)}
                        className="w-4 h-4 text-[var(--color-accent-gold)] focus:ring-[var(--color-accent-gold)]"
                      />
                      <span className="ml-3 text-[var(--color-primary-text)]/80 group-hover:text-[var(--color-accent-maroon)]">
                        {occasion}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <main className="lg:col-span-3">
            {/* Mobile Filter Toggle */}
            <div className="lg:hidden mb-6 flex items-center justify-between">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="px-4 py-2 bg-[var(--color-accent-maroon)] text-white rounded-lg"
              >
                {showFilters ? "Hide Filters" : "Show Filters"}
              </button>
              <p className="text-[var(--color-primary-text)]/70">
                {filteredProducts.length} {filteredProducts.length === 1 ? "saree" : "sarees"}
              </p>
            </div>

            <div className="hidden lg:flex items-center justify-between mb-8">
              <p className="text-[var(--color-primary-text)]/70">
                Showing {filteredProducts.length} of {products.length} sarees
              </p>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-xl text-[var(--color-primary-text)]/60 mb-4">
                  No sarees found matching your criteria
                </p>
                <button
                  onClick={clearFilters}
                  className="text-[var(--color-accent-gold)] hover:text-[var(--color-accent-maroon)]"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Link to={`/collection/${product.id}`} className="group block">
                      <div className="relative h-80 mb-4 overflow-hidden rounded-lg shadow-lg">
                        <ImageWithFallback
                          src={product.imageUrl}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-3 right-3 bg-[var(--color-accent-gold)] text-[var(--color-primary-text)] px-3 py-1 text-xs rounded-full">
                          {product.clothType}
                        </div>
                        <div className="absolute bottom-3 left-3 bg-white/90 text-[var(--color-primary-text)] px-3 py-1 text-xs rounded-full">
                          {product.occasion}
                        </div>
                      </div>
                      <h3 className="font-heading text-xl mb-2 text-[var(--color-primary-text)] group-hover:text-[var(--color-accent-maroon)] transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-[var(--color-primary-text)]/70 mb-2 text-sm">
                        {product.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <p className="text-[var(--color-accent-gold)]">{product.price}</p>
                        <p className="text-xs text-[var(--color-primary-text)]/60">
                          {product.weavingTime}
                        </p>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
