import { useParams, Link } from "react-router";
import { motion } from "motion/react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import { products } from "@/app/data/products";
import { ArrowLeft, MessageCircle } from "lucide-react";

export default function ProductDetail() {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-heading text-4xl mb-4">Product Not Found</h1>
          <Link to="/collection" className="text-[var(--color-accent-gold)] hover:text-[var(--color-accent-maroon)]">
            Back to Collection
          </Link>
        </div>
      </div>
    );
  }

  const handleWhatsAppInquiry = () => {
    const message = `Hi, I'm interested in ${product.name} (${product.clothType})`;
    const whatsappUrl = `https://wa.me/910000000000?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-[var(--color-primary-bg)]">
      {/* Back Button */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <Link 
          to="/collection" 
          className="inline-flex items-center gap-2 text-[var(--color-accent-gold)] hover:text-[var(--color-accent-maroon)] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Collection
        </Link>
      </div>

      {/* Product Details */}
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative h-[600px] rounded-lg overflow-hidden shadow-2xl mb-4">
              <ImageWithFallback
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="relative h-32 rounded-lg overflow-hidden shadow-md opacity-60 hover:opacity-100 transition-opacity cursor-pointer">
                  <ImageWithFallback
                    src={product.imageUrl}
                    alt={`${product.name} view ${i}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </motion.div>

          {/* Product Information */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {/* Title and Occasion */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="px-3 py-1 bg-[var(--color-accent-gold)]/20 text-[var(--color-accent-maroon)] text-sm rounded-full">
                  {product.clothType}
                </span>
                <span className="px-3 py-1 bg-[var(--color-neutral-beige)] text-[var(--color-primary-text)] text-sm rounded-full">
                  {product.occasion}
                </span>
              </div>
              <h1 className="font-heading text-4xl md:text-5xl mb-4 text-[var(--color-primary-text)]">
                {product.name}
              </h1>
              <p className="text-xl text-[var(--color-primary-text)]/80 mb-4">
                {product.description}
              </p>
              <p className="text-3xl text-[var(--color-accent-gold)]">{product.price}</p>
            </div>

            {/* Weaving Time */}
            <div className="mb-8 p-4 bg-[var(--color-neutral-beige)] rounded-lg">
              <p className="text-sm text-[var(--color-primary-text)]/70">Handwoven in</p>
              <p className="font-heading text-2xl text-[var(--color-accent-maroon)]">
                {product.weavingTime}
              </p>
            </div>

            {/* Story */}
            <div className="mb-8">
              <h2 className="font-heading text-2xl mb-4 text-[var(--color-primary-text)]">
                The Story
              </h2>
              <p className="text-[var(--color-primary-text)]/80 leading-relaxed">
                {product.story}
              </p>
            </div>

            {/* Colors */}
            <div className="mb-8">
              <h2 className="font-heading text-2xl mb-4 text-[var(--color-primary-text)]">
                Colors
              </h2>
              <div className="flex gap-2">
                {product.colors.map((color) => (
                  <span 
                    key={color}
                    className="px-4 py-2 bg-white border border-[var(--color-neutral-beige)] rounded-full text-sm text-[var(--color-primary-text)]"
                  >
                    {color}
                  </span>
                ))}
              </div>
            </div>

            {/* Fabric Details */}
            <div className="mb-8">
              <h2 className="font-heading text-2xl mb-4 text-[var(--color-primary-text)]">
                Fabric Details
              </h2>
              <div className="bg-white p-6 rounded-lg space-y-3">
                <div className="flex justify-between border-b border-[var(--color-neutral-beige)] pb-2">
                  <span className="text-[var(--color-primary-text)]/70">Material</span>
                  <span className="text-[var(--color-primary-text)]">{product.fabricDetails.material}</span>
                </div>
                <div className="flex justify-between border-b border-[var(--color-neutral-beige)] pb-2">
                  <span className="text-[var(--color-primary-text)]/70">Weave Type</span>
                  <span className="text-[var(--color-primary-text)]">{product.fabricDetails.weave}</span>
                </div>
                <div className="flex justify-between border-b border-[var(--color-neutral-beige)] pb-2">
                  <span className="text-[var(--color-primary-text)]/70">Dimensions</span>
                  <span className="text-[var(--color-primary-text)]">{product.fabricDetails.dimensions}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--color-primary-text)]/70">Weight</span>
                  <span className="text-[var(--color-primary-text)]">{product.fabricDetails.weight}</span>
                </div>
              </div>
            </div>

            {/* Care Instructions */}
            <div className="mb-8">
              <h2 className="font-heading text-2xl mb-4 text-[var(--color-primary-text)]">
                Care Instructions
              </h2>
              <ul className="space-y-2">
                {product.careInstructions.map((instruction, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-[var(--color-accent-gold)] mt-1">•</span>
                    <span className="text-[var(--color-primary-text)]/80">{instruction}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CTA Buttons */}
            <div className="space-y-4">
              <button
                onClick={handleWhatsAppInquiry}
                className="w-full px-8 py-4 bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)] hover:bg-[var(--color-accent-gold)] hover:text-[var(--color-primary-text)] transition-all duration-300 flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                Inquire via WhatsApp
              </button>
              <Link
                to="/contact"
                className="w-full px-8 py-4 border-2 border-[var(--color-accent-maroon)] text-[var(--color-accent-maroon)] hover:bg-[var(--color-accent-maroon)] hover:text-[var(--color-primary-bg)] transition-all duration-300 flex items-center justify-center"
              >
                Contact Us
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        <div className="mt-20">
          <h2 className="font-heading text-3xl mb-8 text-[var(--color-accent-maroon)]">
            You May Also Like
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products
              .filter((p) => p.id !== product.id && p.clothType === product.clothType)
              .slice(0, 3)
              .map((relatedProduct) => (
                <Link key={relatedProduct.id} to={`/collection/${relatedProduct.id}`} className="group">
                  <div className="relative h-64 mb-4 overflow-hidden rounded-lg shadow-lg">
                    <ImageWithFallback
                      src={relatedProduct.imageUrl}
                      alt={relatedProduct.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <h3 className="font-heading text-xl mb-2 text-[var(--color-primary-text)] group-hover:text-[var(--color-accent-maroon)]">
                    {relatedProduct.name}
                  </h3>
                  <p className="text-[var(--color-accent-gold)]">{relatedProduct.price}</p>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
