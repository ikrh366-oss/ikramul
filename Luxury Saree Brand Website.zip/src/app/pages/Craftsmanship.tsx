import { motion } from "motion/react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export default function Craftsmanship() {
  const steps = [
    {
      step: "01",
      title: "Thread Selection",
      description: "The journey begins with selecting the finest cotton or silk threads. Each thread is carefully inspected for quality, strength, and texture. The choice of thread determines the saree's drape, feel, and longevity.",
      details: [
        "100% pure materials sourced from trusted suppliers",
        "Thread count and quality verified at multiple stages",
        "Natural dyes preferred for eco-friendly coloring"
      ]
    },
    {
      step: "02",
      title: "Design Planning",
      description: "Master weavers sketch intricate patterns, often drawing from centuries-old motifs and traditional designs. This stage requires deep knowledge of weaving techniques and artistic vision.",
      details: [
        "Traditional motifs combined with contemporary aesthetics",
        "Patterns mapped on graph paper for precision",
        "Color combinations thoughtfully planned"
      ]
    },
    {
      step: "03",
      title: "Loom Preparation",
      description: "The pit loom or handloom is carefully set up with thousands of threads. This meticulous process can take several days and requires exceptional skill and patience.",
      details: [
        "Warp threads mounted with precision",
        "Tension adjusted for perfect weaving",
        "Shuttle prepared with weft threads"
      ]
    },
    {
      step: "04",
      title: "Hand Weaving",
      description: "The master artisan begins the actual weaving process. Each movement is deliberate, each thread placed with care. For complex patterns like Jamdani, this is where true artistry shines.",
      details: [
        "8-12 hours of daily weaving",
        "Intricate motifs woven by hand without machinery",
        "Traditional techniques passed through generations"
      ]
    },
    {
      step: "05",
      title: "Quality Inspection",
      description: "Every inch of the saree is carefully examined for any imperfections. The pattern alignment, thread tension, and color consistency are all verified.",
      details: [
        "Multi-stage quality checks",
        "Pattern and weave integrity verified",
        "Any minor flaws corrected by hand"
      ]
    },
    {
      step: "06",
      title: "Finishing Touches",
      description: "The saree is carefully removed from the loom, edges are finished, and final embellishments are added. A gentle wash brings out the fabric's natural luster.",
      details: [
        "Edges carefully secured and finished",
        "Gentle washing to enhance texture",
        "Final pressing and folding with care"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[var(--color-primary-bg)]">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-[var(--color-neutral-beige)]">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-heading text-5xl md:text-6xl mb-6 text-[var(--color-accent-maroon)]"
          >
            The Art of Craftsmanship
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-[var(--color-primary-text)]/80"
          >
            From thread to treasure: The journey of creating a handwoven masterpiece
          </motion.p>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          {steps.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className={`grid md:grid-cols-2 gap-12 items-center mb-24 ${
                index % 2 === 1 ? 'md:grid-flow-dense' : ''
              }`}
            >
              <div className={index % 2 === 1 ? 'md:col-start-2' : ''}>
                <div className="text-6xl font-heading text-[var(--color-accent-gold)] mb-4">
                  {item.step}
                </div>
                <h2 className="font-heading text-4xl mb-4 text-[var(--color-accent-maroon)]">
                  {item.title}
                </h2>
                <p className="text-lg mb-6 text-[var(--color-primary-text)]/80 leading-relaxed">
                  {item.description}
                </p>
                <ul className="space-y-2">
                  {item.details.map((detail, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-[var(--color-accent-gold)] mt-1">•</span>
                      <span className="text-[var(--color-primary-text)]/70">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className={`relative h-80 rounded-lg overflow-hidden shadow-2xl ${
                index % 2 === 1 ? 'md:col-start-1 md:row-start-1' : ''
              }`}>
                <ImageWithFallback
                  src={`https://images.unsplash.com/photo-${index % 2 === 0 ? '1739185127141-bb4aa70ad22a' : '1742287721821-ddf522b3f37b'}?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbG9vbSUyMHdlYXZpbmclMjBhcnRpc2FufGVufDF8fHx8MTc2OTA3MjkzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral`}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Time Investment */}
      <section className="py-20 px-4 bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading text-4xl mb-6">The Value of Time</h2>
          <p className="text-lg mb-8 opacity-90 leading-relaxed">
            A single handwoven saree can take anywhere from 15 to 60 days to complete, depending on the 
            complexity of the design. This time investment is what makes each piece truly special — 
            it's not just a garment, but a labor of love and dedication.
          </p>
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            {[
              { time: "15-25 days", type: "Simple Cotton Sarees" },
              { time: "30-40 days", type: "Intricate Silk Sarees" },
              { time: "45-60 days", type: "Complex Jamdani & Muslin" }
            ].map((item, index) => (
              <div key={index} className="bg-white/10 p-6 rounded-lg backdrop-blur-sm">
                <div className="text-3xl font-heading text-[var(--color-accent-gold)] mb-2">
                  {item.time}
                </div>
                <p className="opacity-90">{item.type}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
