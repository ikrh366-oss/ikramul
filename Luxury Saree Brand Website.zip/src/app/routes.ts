import { createBrowserRouter } from "react-router";
import Root from "@/app/components/Root";
import Home from "@/app/pages/Home";
import About from "@/app/pages/About";
import Collection from "@/app/pages/Collection";
import ProductDetail from "@/app/pages/ProductDetail";
import Craftsmanship from "@/app/pages/Craftsmanship";
import Contact from "@/app/pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "about", Component: About },
      { path: "collection", Component: Collection },
      { path: "collection/:id", Component: ProductDetail },
      { path: "craftsmanship", Component: Craftsmanship },
      { path: "contact", Component: Contact },
    ],
  },
]);
