export default function Footer() {
  return (
    <footer className="bg-[var(--color-accent-maroon)] text-[var(--color-primary-bg)] mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <h3 className="font-heading text-2xl mb-4">Heritage Sarees</h3>
            <p className="text-sm opacity-90">
              Preserving tradition through handwoven excellence. Each saree tells a story of artisan craftsmanship.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/about" className="opacity-90 hover:opacity-100 hover:text-[var(--color-accent-gold)] transition-colors">About Us</a></li>
              <li><a href="/collection" className="opacity-90 hover:opacity-100 hover:text-[var(--color-accent-gold)] transition-colors">Collection</a></li>
              <li><a href="/craftsmanship" className="opacity-90 hover:opacity-100 hover:text-[var(--color-accent-gold)] transition-colors">Craftsmanship</a></li>
              <li><a href="/contact" className="opacity-90 hover:opacity-100 hover:text-[var(--color-accent-gold)] transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-heading text-lg mb-4">Get in Touch</h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li>Email: contact@heritagesarees.com</li>
              <li>Phone: +91 00000 00000</li>
              <li>WhatsApp: +91 00000 00000</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-[var(--color-primary-bg)]/20 mt-8 pt-8 text-center text-sm opacity-75">
          <p>&copy; 2026 Heritage Sarees. Woven by Hand. Preserved by Tradition.</p>
        </div>
      </div>
    </footer>
  );
}
