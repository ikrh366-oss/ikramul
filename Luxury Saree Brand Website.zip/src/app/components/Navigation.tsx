import { Link, useLocation } from "react-router";
import { motion } from "motion/react";
import { useState } from "react";
import { X, Menu } from "lucide-react";

const navItems = [
  { name: "Home", path: "/" },
  { name: "About the Brand", path: "/about" },
  { name: "Collection", path: "/collection" },
  { name: "Craftsmanship", path: "/craftsmanship" },
  { name: "Contact", path: "/contact" },
];

export default function Navigation() {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <motion.nav 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="sticky top-0 z-50 bg-[var(--color-primary-bg)] border-b border-[var(--color-neutral-beige)]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <h1 className="font-heading text-3xl tracking-wide text-[var(--color-accent-maroon)]">
              Heritage Sarees
            </h1>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path || 
                              (item.path !== "/" && location.pathname.startsWith(item.path));
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`font-body text-sm tracking-wide transition-colors relative group ${
                    isActive 
                      ? "text-[var(--color-accent-gold)]" 
                      : "text-[var(--color-primary-text)] hover:text-[var(--color-accent-gold)]"
                  }`}
                >
                  {item.name}
                  <span className={`absolute -bottom-1 left-0 h-px bg-[var(--color-accent-gold)] transition-all ${
                    isActive ? "w-full" : "w-0 group-hover:w-full"
                  }`} />
                </Link>
              );
            })}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-[var(--color-primary-text)]"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-[var(--color-neutral-beige)] py-4"
          >
            <div className="flex flex-col space-y-4">
              {navItems.map((item) => {
                const isActive = location.pathname === item.path || 
                                (item.path !== "/" && location.pathname.startsWith(item.path));
                
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`font-body text-sm tracking-wide transition-colors py-2 ${
                      isActive 
                        ? "text-[var(--color-accent-gold)]" 
                        : "text-[var(--color-primary-text)] hover:text-[var(--color-accent-gold)]"
                    }`}
                  >
                    {item.name}
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}