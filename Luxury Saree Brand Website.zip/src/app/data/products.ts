export interface Product {
  id: string;
  name: string;
  clothType: "Jamdani" | "Tangail" | "Silk" | "Cotton" | "Muslin-inspired";
  description: string;
  price: string;
  weavingTime: string;
  colors: string[];
  occasion: "Bridal" | "Festive" | "Everyday Elegance";
  imageUrl: string;
  story: string;
  careInstructions: string[];
  fabricDetails: {
    material: string;
    weave: string;
    dimensions: string;
    weight: string;
  };
}

export const products: Product[] = [
  {
    id: "1",
    name: "Royal Jamdani Heritage",
    clothType: "Jamdani",
    description: "Handwoven with intricate floral motifs",
    price: "Contact for Price",
    weavingTime: "45 days",
    colors: ["Crimson", "Gold"],
    occasion: "Bridal",
    imageUrl: "https://images.unsplash.com/photo-1742287721821-ddf522b3f37b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBzaWxrJTIwc2FyZWUlMjB0cmFkaXRpb25hbHxlbnwxfHx8fDE3NjkwNDgyMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    story: "This exquisite Jamdani saree represents the pinnacle of Bengali weaving artistry. Each motif is meticulously woven by hand, requiring 45 days of dedicated craftsmanship. The intricate patterns tell stories of royal heritage and timeless elegance.",
    careInstructions: [
      "Dry clean only",
      "Store in a cool, dry place",
      "Avoid direct sunlight",
      "Refold periodically to prevent creases"
    ],
    fabricDetails: {
      material: "100% Pure Cotton with Zari",
      weave: "Traditional Jamdani",
      dimensions: "5.5 meters x 1.2 meters",
      weight: "450 grams"
    }
  },
  {
    id: "2",
    name: "Tangail Elegance",
    clothType: "Tangail",
    description: "Classic geometric patterns in pure cotton",
    price: "₹18,500",
    weavingTime: "25 days",
    colors: ["Indigo", "Ivory"],
    occasion: "Festive",
    imageUrl: "https://images.unsplash.com/photo-1739185127141-bb4aa70ad22a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbG9vbSUyMHdlYXZpbmclMjBhcnRpc2FufGVufDF8fHx8MTc2OTA3MjkzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    story: "Tangail sarees have adorned Bengali women for generations. This piece features geometric patterns that dance across the pallu, woven with precision by master artisans who have inherited this craft through family lineages.",
    careInstructions: [
      "Hand wash with mild detergent",
      "Dry in shade",
      "Iron on medium heat",
      "Store folded in muslin cloth"
    ],
    fabricDetails: {
      material: "100% Pure Cotton",
      weave: "Traditional Tangail",
      dimensions: "5.5 meters x 1.15 meters",
      weight: "380 grams"
    }
  },
  {
    id: "3",
    name: "Silk Radiance",
    clothType: "Silk",
    description: "Lustrous silk with traditional temple border",
    price: "₹32,000",
    weavingTime: "35 days",
    colors: ["Emerald", "Gold"],
    occasion: "Bridal",
    imageUrl: "https://images.unsplash.com/photo-1761516659547-3000a0b1c0bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZXh0aWxlJTIwcGF0dGVybnMlMjB0cmFkaXRpb25hbHxlbnwxfHx8fDE3NjkwNzI5Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    story: "Woven in pure mulberry silk, this saree embodies the grandeur of South Indian temple architecture. The intricate border patterns are inspired by centuries-old temple carvings, created using traditional pit-loom techniques.",
    careInstructions: [
      "Dry clean only",
      "Avoid water contact",
      "Store in breathable silk pouch",
      "Keep away from perfumes"
    ],
    fabricDetails: {
      material: "Pure Mulberry Silk with Zari",
      weave: "Temple Border Silk",
      dimensions: "6 meters x 1.2 meters",
      weight: "550 grams"
    }
  },
  {
    id: "4",
    name: "Cotton Comfort Classic",
    clothType: "Cotton",
    description: "Soft cotton with delicate woven borders",
    price: "₹12,500",
    weavingTime: "18 days",
    colors: ["Rust", "Beige"],
    occasion: "Everyday Elegance",
    imageUrl: "https://images.unsplash.com/photo-1742287721821-ddf522b3f37b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBzaWxrJTIwc2FyZWUlMjB0cmFkaXRpb25hbHxlbnwxfHx8fDE3NjkwNDgyMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    story: "Perfect for daily wear, this cotton saree combines comfort with elegance. Handwoven by rural artisans, it represents the beauty of simplicity and sustainable fashion.",
    careInstructions: [
      "Hand wash or gentle machine wash",
      "Use natural detergents",
      "Line dry in shade",
      "Iron while slightly damp"
    ],
    fabricDetails: {
      material: "100% Organic Cotton",
      weave: "Plain Weave with Jacquard Border",
      dimensions: "5.5 meters x 1.1 meters",
      weight: "320 grams"
    }
  },
  {
    id: "5",
    name: "Muslin Dream",
    clothType: "Muslin-inspired",
    description: "Ultra-fine muslin with ethereal drape",
    price: "Contact for Price",
    weavingTime: "60 days",
    colors: ["Pearl White", "Silver"],
    occasion: "Bridal",
    imageUrl: "https://images.unsplash.com/photo-1739185127141-bb4aa70ad22a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbG9vbSUyMHdlYXZpbmclMjBhcnRpc2FufGVufDF8fHx8MTc2OTA3MjkzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    story: "Inspired by the legendary Dhaka muslin, this saree is woven from the finest cotton threads. So delicate it can pass through a ring, yet so strong it lasts generations. A true masterpiece of textile artistry.",
    careInstructions: [
      "Dry clean only - specialized care required",
      "Handle with extreme care",
      "Store flat in acid-free tissue",
      "Avoid any moisture"
    ],
    fabricDetails: {
      material: "Ultra-fine Cotton (300+ thread count)",
      weave: "Muslin-inspired Fine Weave",
      dimensions: "5.5 meters x 1.2 meters",
      weight: "250 grams"
    }
  },
  {
    id: "6",
    name: "Festive Tangail Glory",
    clothType: "Tangail",
    description: "Vibrant colors with traditional butis",
    price: "₹22,000",
    weavingTime: "28 days",
    colors: ["Magenta", "Gold"],
    occasion: "Festive",
    imageUrl: "https://images.unsplash.com/photo-1761516659547-3000a0b1c0bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZXh0aWxlJTIwcGF0dGVybnMlMjB0cmFkaXRpb25hbHxlbnwxfHx8fDE3NjkwNzI5Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    story: "This festive Tangail saree celebrates color and tradition. The vibrant butis scattered across the body are woven with golden threads, creating a saree perfect for celebrations and joyous occasions.",
    careInstructions: [
      "Dry clean recommended",
      "Can be hand washed with care",
      "Dry in shade",
      "Iron on reverse side"
    ],
    fabricDetails: {
      material: "Cotton-Silk Blend with Zari",
      weave: "Tangail with Buti Work",
      dimensions: "5.5 meters x 1.15 meters",
      weight: "420 grams"
    }
  }
];
